TEXTURAS 2048 REALISTAS (tileables)
--------------------------------
Nombres (NO cambiar):
- ground_asphalt.jpg      -> vialidades / patio negro
- ground_concrete.jpg     -> patio de maniobras claro (cemento)
- ground_dirt.jpg         -> tierra exterior / zonas sin pavimento
- wall_white_concrete.jpg -> barda blanca
- roof_white.jpg          -> techo nave blanca
- roof_blue.jpg           -> techumbre azul (si aplica)

Sugerencia de carpeta:
assets/textures/

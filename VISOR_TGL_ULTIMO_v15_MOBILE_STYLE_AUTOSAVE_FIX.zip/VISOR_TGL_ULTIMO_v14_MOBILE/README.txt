CCTV — Visor 3D manipulable (v4)

Novedades:
- Calibrar escala (metros): click 2 puntos y escribe la distancia real.
- Modo perímetro: click esquinas y genera cercado 3D.
- Export/Import: guarda cámaras + perímetro + escala en JSON.

Uso rápido:
1) py -m http.server 8000
2) http://localhost:8000
3) Calibrar escala: click en extremos del tramo "650 m" y escribe 650.
4) Perímetro: click esquinas -> Cerrar/Generar cercado.
5) Cámaras: Modo cámara -> click para colocar.
6) Exportar: copia JSON. Importar: pega JSON y Ctrl+Enter.

Offline:
- Si tu red bloquea CDNs, ejecuta download_vendor.bat y recarga (Ctrl+F5).
